using System.Reflection;

[assembly: AssemblyTitle("OpenPopUnitTests")]
[assembly: AssemblyDescription("Unit tests for the OpenPop POP3 Mail Library")]